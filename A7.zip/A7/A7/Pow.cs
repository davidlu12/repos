﻿// A7, David Lu, CIS345, T-Th 12pm
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace A7
{
    public partial class Pow : Form
    {
        // declare variables
        Random r;
        int targetSpeed;
        int totalScore;
        int secondsLeft;
        SoundPlayer soundPlayer;

        public Pow()
        {
            InitializeComponent();
        }

        //  start the game and reset all the properties to an initial state.It then starts the game by starting the timers.
        private void startButton_Click(object sender, EventArgs e)
        {
            r = new Random();
            targetSpeed = r.Next(4,15);
            targetTimer.Interval = 20;
            gameTimer.Interval = 1000;
            bulletTimer.Interval = 10;
            powTimer.Interval = 5;
            targetPictureBox.Left = 0;
            bulletPictureBox.Top = 210;
            totalScore = 0;
            powPrefixLabel.Text = Convert.ToString(totalScore);
            statusLabel.Visible = true;
            targetPictureBox.Visible = true;
            bulletPictureBox.Visible = true;
            powSuffixLabel.Visible = true;
            powPrefixLabel.Visible = true;
            fireButton.Visible = true;
            fireButton.Enabled = true;
            secondsLeft = 60;
            statusLabel.Text = Convert.ToString(secondsLeft);
            targetTimer.Start();
            gameTimer.Start();
        }

        //  moves the target bullet to the right. When the bullet comes on the screen from the left, it will select a new random speed.
        private void targetTimer_Tick(object sender, EventArgs e)
        {
            targetPictureBox.Left += targetSpeed;
            if(targetPictureBox.Left >= this.Width)
            {
                Point point = new Point(0,34);
                targetPictureBox.Location = point;
                targetSpeed = r.Next(4,15);
            }
        }

        // updates the game timer by changing the label text and updating the secondsLeft variable.
        private void gameTimer_Tick(object sender, EventArgs e)
        {
            secondsLeft -= 1;
            if(secondsLeft >0)
            {
                statusLabel.Text = Convert.ToString(secondsLeft);
            }
            else
            {
                gameTimer.Stop();
                bulletTimer.Stop();
                targetTimer.Stop();
                fireButton.Enabled = false;
                statusLabel.Text = "Game over";
            }
        }

        // fires the bullet by setting starting up the appropriate Bullet timer
        private void fireButton_Click(object sender, EventArgs e)
        {
            bulletPictureBox.Visible = true;
            bulletTimer.Start();
        }

        //  sets what happens at every tick event for the bullet that was fired. 
        private void bulletTimer_Tick(object sender, EventArgs e)
        {
            bulletPictureBox.Top -= 7;
            if(Collide())
            {
                totalScore++;
                powPrefixLabel.Text = Convert.ToString(totalScore);
                bulletTimer.Stop();
                targetTimer.Stop();
                targetPictureBox.ImageLocation = "pow.png";
                targetPictureBox.Height = 0;
                targetPictureBox.Width = 0;
                bulletPictureBox.Visible = false;
                powTimer.Start();
            }
            if(bulletPictureBox.Top <=0)
            {
                bulletTimer.Stop();
                bulletPictureBox.Visible = true;
                bulletPictureBox.Top = 210;
            }
        }

        //  tests if the target bullet and the fired bullet have collided.
        private bool Collide()
        {
            if((bulletPictureBox.Left >= targetPictureBox.Left && bulletPictureBox.Left<=targetPictureBox.Right)
                &&(bulletPictureBox.Top<= targetPictureBox.Bottom && bulletPictureBox.Top >= targetPictureBox.Top))
            {
                return true;
            }
            if((bulletPictureBox.Right>= targetPictureBox.Left && bulletPictureBox.Right <= targetPictureBox.Right)
                &&(bulletPictureBox.Top< targetPictureBox.Bottom && bulletPictureBox.Top>= targetPictureBox.Top))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //  adds a rudimentary animation to show that the two bullets collided by displaying the Pow image.
        private void powTimer_Tick(object sender, EventArgs e)
        {
            targetPictureBox.Height++;
            targetPictureBox.Width++;
            if(targetPictureBox.Width == 50)
            {
                powTimer.Stop();
                bulletPictureBox.Top = 210;
                bulletPictureBox.Visible = true;
                targetPictureBox.Height = 40;
                targetPictureBox.Width = 40;
                Point point = new Point(0,34);
                targetPictureBox.Location = point;
                targetPictureBox.ImageLocation = "ship.png";
                targetSpeed = r.Next(4,15);
                targetTimer.Start();
            }
        }

        // execute before Window and create the environment for the looping sound file
        private void Pow_Load(object sender, EventArgs e)
        {
            soundPlayer = new SoundPlayer("s2.wav");
            soundPlayer.Load();
            soundPlayer.PlayLooping();
        }
    }
}
