﻿// Project, David Lu, CIS 345, T-TH 12pm
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TriviaNow
{
    public partial class TriviaManager : Form
    {
        AddQuestion dataForm;
        BindingList<Question> questionList;

        public TriviaManager()
        {
            InitializeComponent();
        }

        private void DataForm_NewQuestionAdded(object sender, EventArgs e)
        {
            DataEntryEventArgs tmpArgs = null;

            // //check if e is of type DataEntryEventArgs
            if (e is DataEntryEventArgs)
            {
                tmpArgs = (DataEntryEventArgs)e;
                Question tmpQuestion = tmpArgs.Question;
                questionList.Add(tmpQuestion);
                statusLabel.Text = $"New Question Added";
            }
        }

        //This method will “register” the event handlers by instantiating the events declared as fields.
        private void QuestionCreatedEventHandlers()
        {
            // set eventhandler for NewProductCreatedEvent
            dataForm.NewQuestionAdded += new QuestionAdded(this.DataForm_NewQuestionAdded);
        }

        private void addQuestionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataForm = new AddQuestion();
            dataForm.Show();
            QuestionCreatedEventHandlers();
        }

        private void TriviaManager_Load(object sender, EventArgs e)
        {
            questionList = new BindingList<Question>();
            questionsListBox.DataSource = questionList;
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog.FileName = "";
            saveFileDialog.Filter = "App Data Files (*.dat)|*.dat|All Files (*.*)|*.*";
            DialogResult dialogResult = saveFileDialog.ShowDialog();

            if (dialogResult == DialogResult.OK)
            {
                string fileName = saveFileDialog.FileName;
                try
                {
                    FileStream file = new FileStream(fileName, FileMode.Create, FileAccess.Write);
                    BinaryFormatter bf = new BinaryFormatter();
                    bf.Serialize(file, questionList);
                    file.Close();
                    statusLabel.Text = "File Saved Successful";
                }
                catch (Exception)
                {
                    statusLabel.Text = "File Saved not Successful";
                }
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                openFileDialog.FileName = "";
                openFileDialog.Filter = "App Data Files (*.dat)|*.dat|All Files (*.*)|*.*";
                DialogResult dialogResult = openFileDialog.ShowDialog();

                if (dialogResult == DialogResult.OK)
                {
                    string fileName = openFileDialog.FileName;
                    FileStream file = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                    BinaryFormatter bf = new BinaryFormatter();
                    questionList = (BindingList<Question>)bf.Deserialize(file);
                    questionsListBox.DataSource = questionList;
                    statusLabel.Text = "File Loaded";
                }
            }
            catch (Exception)
            {
                statusLabel.Text = "File Load Not Successful";
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }
    }
}
