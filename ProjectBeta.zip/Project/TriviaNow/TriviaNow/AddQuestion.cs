﻿// Project, David Lu, CIS 345, T-TH 12pm
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TriviaNow
{
    // step 1
    public delegate void QuestionAdded(object sender, EventArgs e);

    public partial class AddQuestion : Form
    {
        // Step 2: event productAdded is being declared
        public event QuestionAdded NewQuestionAdded;

        public AddQuestion()
        {
            InitializeComponent();
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            // check if all textboxes are inputed
            if (questionTextBox.Text == String.Empty || choice1TextBox.Text == String.Empty || choice2TextBox.Text == String.Empty || choice3TextBox.Text == String.Empty
                || choice4TextBox.Text == String.Empty || feedbackTextBox.Text == String.Empty || correctChoiceTextBox.Text == String.Empty)
            {
                MessageBox.Show("Please enter all information!");
                return;
            }
            // check if correct choice is entered numerically and if number is between 1-4
            if (correctChoiceTextBox.Text != string.Empty)
            {
                bool numericChoice = double.TryParse(correctChoiceTextBox.Text, out double choice);
                if (numericChoice != true)
                {
                    MessageBox.Show("Please enter a numeric value(1-4) for Correct Choice ");
                    return;
                }
                if (choice > 4 || choice < 1)
                {
                    MessageBox.Show("Please enter a numeric value(1-4) for Correct Choice ");
                    return;
                }
            }

            Question tmpQuestion = new Question(questionTextBox.Text, choice1TextBox.Text, choice2TextBox.Text, choice3TextBox.Text,
                choice4TextBox.Text, feedbackTextBox.Text, correctChoiceTextBox.Text);

            DataEntryEventArgs tmpArgs = new DataEntryEventArgs(tmpQuestion);

            // Step 3: fire or trigger the event
            if (NewQuestionAdded != null)
            {
                NewQuestionAdded(this,tmpArgs);
            }

            questionTextBox.Text = string.Empty;
            choice1TextBox.Text = string.Empty;
            choice2TextBox.Text = string.Empty;
            choice3TextBox.Text = string.Empty;
            choice4TextBox.Text = string.Empty;
            feedbackTextBox.Text = string.Empty;
            correctChoiceTextBox.Text = string.Empty;

        }
    }
}
