﻿// A5, David Lu, CIS 345, T-Th 12pm
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A5
{
    public partial class ProductManager : Form
    {
        // variable of type DataEntry
        AddNewProduct dataForm;
        ProductDetails updateForm;
        Product selectedProduct;
        BindingList<Product> productList;

        public ProductManager()
        {
            InitializeComponent();
        }

        // This method will be the event handler method, which is executed when a new product is created.
        private void DataForm_NewProductCreated(object sender, EventArgs e)
        {
            // event handler for NewProductCreated method
            // The EventArgs object is actually a DataEntryEventArgs object
            // Downcast it and store it in a variable of type DataEntryEventArgs
            DataEntryEventArgs tmpArgs = null;

            //check if e is of type DataEntryEventArgs
            if (e is DataEntryEventArgs)
            {
                tmpArgs = (DataEntryEventArgs)e;
                Product tmpProduct = tmpArgs.Product;
                productList.Add(tmpProduct);
            }
        }

        //This method will “register” the event handlers by instantiating the events declared as fields.
        private void SetEventHandlers()
        {
            // set eventhandler for NewProductCreatedEvent
            dataForm.NewProductAdded += new ProductAdded(this.DataForm_NewProductCreated);
        }

        // This method will be the event handler method, which will be executed when the user presses the new product button to open the add new product form.
        private void newProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataForm = new AddNewProduct();
            dataForm.Show();
            SetEventHandlers();
        }

        // This method will be the event handler method, which will be executed when the user selects a product in the ListBox
        private void productListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (productListBox.SelectedItem != null)
            {
                Product tmpProduct = (Product)productListBox.SelectedItem;
                nameTextBox.Text = tmpProduct.Name;
                idTextBox.Text = tmpProduct.Id;
            }
        }

        // The Load event handler will initialize the List and bind the ListBox to the List
        private void ProductManager_Load(object sender, EventArgs e)
        {
            productList = new BindingList<Product>();
            productListBox.DataSource = productList;
        }

        private void UpdateForm_Product(object sender, EventArgs e)
        {
            if (e is DataEntryEventArgs)
            {
                DataEntryEventArgs tmpArgs = (DataEntryEventArgs)e;
                Product tmpProduct = tmpArgs.Product;
                productList.ResetBindings();
                nameTextBox.Text = tmpProduct.Name;
                idTextBox.Text = tmpProduct.Id;
            }
        }

        // This method will open the product details form to show details of product
        private void detailsButton_Click(object sender, EventArgs e)
        {
            if (productListBox.SelectedItem == null)
            {
                return;
            }
            selectedProduct = (Product)productListBox.SelectedItem;
            updateForm = new ProductDetails();
            updateForm.ProductUpdated += new EventHandler(this.UpdateForm_Product);
            updateForm.PopulateData(selectedProduct);
            updateForm.Show();
        }

        // when product is selected, enable the details button
        private void productListBox_Click(object sender, EventArgs e)
        {
            detailsButton.Enabled = true;
        }

        // closes the application
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }
    }
}
