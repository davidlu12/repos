﻿// A5, David Lu, CIS 345, T-Th 12pm
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A5
{
    class DataEntryEventArgs : EventArgs
    {
        // wrapper class
        // encapsulate a product
        Product product;

        public DataEntryEventArgs(Product product)
        {
            this.product = product;
        }

        public Product Product { get => product; set => product = value; }
    }
}
