﻿// A5, David Lu, CIS 345, T-Th 12pm
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A5
{
    public partial class ProductDetails : Form
    {
        public EventHandler ProductUpdated;
        Product currentProduct;

        public ProductDetails()
        {
            InitializeComponent();
        }

        //  allow another client class to call it and populate or fill the form with data
        public void PopulateData(Product product)
        {
            currentProduct = product;
            idTextBox.Text = currentProduct.Id;
            nameTextBox.Text = currentProduct.Name;
            priceTextBox.Text = currentProduct.Price;
            quantityTextBox.Text = currentProduct.Quantity;
        }
    }
}
