﻿// A5, David Lu, CIS 345, T-Th 12pm
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A5
{
    public class Product
    {
        private string name;
        private string id;
        private string price;
        private string quantity;

        public Product(string name, string id)
        {
            this.name = name;
            this.id = id;
            this.price = "";
            this.quantity = "";
        }

        public Product(string name, string id, string price, string quantity)
        {
            this.name = name;
            this.id = id;
            this.price = price;
            this.quantity = quantity;
        }

        public string Name { get => name; set => name = value; }
        public string Id { get => id; set => id = value; }
        public string Price { get => price; set => price = value; }
        public string Quantity { get => quantity; set => quantity = value; }

        public override string ToString()
        {
            return $"{name}";
        }
    }
}
