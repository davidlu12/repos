﻿// A5, David Lu, CIS 345, T-Th 12pm
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A5
{
    // step 1
    public delegate void ProductAdded(object sender, EventArgs e);

    public partial class AddNewProduct : Form
    {
        // Step 2: event productAdded is being declared
        public event ProductAdded NewProductAdded;

        public AddNewProduct()
        {
            InitializeComponent();
        }

        // The program should ensure that both ID and Name have been entered. If not, the user should be informed and no product should be added.
        private void addButton_Click(object sender, EventArgs e)
        {
            // check to see if both ID and name are entered
            if (nameTextBox.Text == String.Empty || idTextBox.Text == String.Empty)
            {
                MessageBox.Show("Please enter both the product Name and ID");
                return;
            }

            // if price or quantities are entered, check if price or quantites are entered numerically
            if (priceTextBox.Text != string.Empty)
            {
                bool numericPrice = double.TryParse(priceTextBox.Text, out double price);
                if (numericPrice != true)
                {
                    MessageBox.Show("Please enter a numeric value for price and/or quantity");
                    return;
                }
            }
            if (quantityTextBox.Text != string.Empty)
            {
                bool numericQty = Int32.TryParse(quantityTextBox.Text, out int quantity);
                if (numericQty != true)
                {
                    MessageBox.Show("Please enter a numeric value for price and/or quantity");
                    return;
                }
            }

            Product tmpProduct = new Product(nameTextBox.Text, idTextBox.Text, priceTextBox.Text, quantityTextBox.Text);
            DataEntryEventArgs tmpArgs = new DataEntryEventArgs(tmpProduct);

            // Step 3: fire or trigger the event
            if (NewProductAdded != null)
                NewProductAdded(this, tmpArgs);

            nameTextBox.Text = string.Empty;
            idTextBox.Text = string.Empty;
            priceTextBox.Text = string.Empty;
            quantityTextBox.Text = string.Empty;
            idTextBox.Focus();
        }
    }
}
