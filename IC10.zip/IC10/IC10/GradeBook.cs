﻿// IC10, David Lu, CIS 345, T-Th 12pm
using System;
using System.Collections.Generic;

namespace IC10
{
    [Serializable]
    public class GradeBook
    {
        private string courseName; // course name for this GradeBook
        private int courseNumber;
        private string collegeName;
        private double classAverage = 0.0;
        List<Student> studentRoster;

             
        // instance variable student count
        private  int studentCount;

        public int StudentCount
        {
            get
            {
                return studentRoster.Count;
            }
        }



        public string CollegeName
        {
            get
            {
                return collegeName;
            }

            set
            {
                collegeName = value;
            }
        } // end property

        public double ClassAverage
        {
            get
            {
                return classAverage;
            }
        }
        // property to get and set the course name
        public string CourseName
        {
            get
            {
                return courseName;
            } // end get

            set
            {
                courseName = value;

            } // end set

        } // end property CourseName

        public int CourseNumber
        {
            get
            {
                return courseNumber;
            }

            set
            {
                if (value > 100 && value < 499)
                    courseNumber = value;
            }
        }

        public List<Student> StudentRoster { get => studentRoster; set => studentRoster = value; }

        public GradeBook()
        {
            studentRoster = new List<Student>();
        }


        public Student AddStudent(string firstName, string lastName)
        {
            // create a new student with the provided name and ID
            Student tmpStudent = new Student(firstName, lastName);
            tmpStudent.Id = Convert.ToString(studentCount);

            // put the student into the array
            // use the student count to properly insert the student
            // in the next available location in the array
            StudentRoster.Add(tmpStudent);

           // increment the student count
            studentCount++;

            return tmpStudent;
        }
                

    } // end class GradeBook

}