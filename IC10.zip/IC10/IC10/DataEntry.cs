﻿// IC10, David Lu, CIS 345, T-Th 12pm
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace IC10
{
    public partial class DataEntry : Form
    {
        //Declare a GradeBook object reference named gb
        //Declare a BindingSource object reference named bs
        GradeBook gb;
        BindingSource bs;

        public DataEntry()
        {
            InitializeComponent();
        }

        // This method will save the data in the GradeBook object to the file by serializing it and saving it to a permanent file.
        private void saveButton_Click(object sender, EventArgs e)
        {
            FileStream file = new FileStream("IC10Data.dat",FileMode.Create, FileAccess.Write);
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(file,gb);
            file.Close();
        }

        // This method will force a manual refresh of the DataGridView by completely resetting binding between the Roster object and the DataGridView.
        private void RefreshDataGrid()
        {
            bs.DataSource = null;
            bs.DataSource = gb;
            bs.DataMember = "StudentRoster";
            dataGridView1.Update();
            dataGridView1.Refresh();
        }

        // This method will read a binary data file and load data from it into the GradeBook object
        private void LoadData()
        {
            try
            {
                FileStream file = new FileStream("IC10Data.dat",FileMode.Open,FileAccess.Read);
                BinaryFormatter bf = new BinaryFormatter();
                gb = (GradeBook)bf.Deserialize(file);
                file.Close();
                RefreshDataGrid();
            }
            catch (FileNotFoundException)
            {

            }
        }

        //The Load event handler is going to initialize the GradeBook and BindingSource and link them together.
        private void DataEntry_Load(object sender, EventArgs e)
        {
            gb = new GradeBook();
            bs = new BindingSource();
            dataGridView1.DataSource = bs;
            LoadData();
        }

        //The Create button is clicked when the user enters finishing a name. It will then add a Student to the GradeBook.
        private void addButton_Click(object sender, EventArgs e)
        {
            gb.AddStudent(firstNameTextBox.Text, lastNameTextBox.Text);
            firstNameTextBox.Text = "";
            lastNameTextBox.Text = "";
            RefreshDataGrid();
        }
    }
}
