﻿namespace TriviaNow
{
    partial class Game
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Game));
            this.choice1RadioButton = new System.Windows.Forms.RadioButton();
            this.choice2RadioButton = new System.Windows.Forms.RadioButton();
            this.choice3RadioButton = new System.Windows.Forms.RadioButton();
            this.choice4RadioButton = new System.Windows.Forms.RadioButton();
            this.submitButton = new System.Windows.Forms.Button();
            this.choice1TextBox = new System.Windows.Forms.TextBox();
            this.choice2TextBox = new System.Windows.Forms.TextBox();
            this.choice3TextBox = new System.Windows.Forms.TextBox();
            this.choice4TextBox = new System.Windows.Forms.TextBox();
            this.questionLabel = new System.Windows.Forms.Label();
            this.feedbackLabel = new System.Windows.Forms.Label();
            this.questionTextBox = new System.Windows.Forms.TextBox();
            this.questionNumberLabel = new System.Windows.Forms.Label();
            this.outOf3Label = new System.Windows.Forms.Label();
            this.startPictureBox = new System.Windows.Forms.PictureBox();
            this.startButton = new System.Windows.Forms.Button();
            this.nextButton = new System.Windows.Forms.Button();
            this.rightPictureBox = new System.Windows.Forms.PictureBox();
            this.wrongPictureBox = new System.Windows.Forms.PictureBox();
            this.feedbackTextBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.startPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rightPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wrongPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // choice1RadioButton
            // 
            this.choice1RadioButton.AutoSize = true;
            this.choice1RadioButton.Checked = true;
            this.choice1RadioButton.Location = new System.Drawing.Point(53, 187);
            this.choice1RadioButton.Name = "choice1RadioButton";
            this.choice1RadioButton.Size = new System.Drawing.Size(84, 21);
            this.choice1RadioButton.TabIndex = 1;
            this.choice1RadioButton.TabStop = true;
            this.choice1RadioButton.Text = "Choice 1";
            this.choice1RadioButton.UseVisualStyleBackColor = true;
            // 
            // choice2RadioButton
            // 
            this.choice2RadioButton.AutoSize = true;
            this.choice2RadioButton.Location = new System.Drawing.Point(53, 230);
            this.choice2RadioButton.Name = "choice2RadioButton";
            this.choice2RadioButton.Size = new System.Drawing.Size(84, 21);
            this.choice2RadioButton.TabIndex = 2;
            this.choice2RadioButton.Text = "Choice 2";
            this.choice2RadioButton.UseVisualStyleBackColor = true;
            // 
            // choice3RadioButton
            // 
            this.choice3RadioButton.AutoSize = true;
            this.choice3RadioButton.Location = new System.Drawing.Point(53, 270);
            this.choice3RadioButton.Name = "choice3RadioButton";
            this.choice3RadioButton.Size = new System.Drawing.Size(84, 21);
            this.choice3RadioButton.TabIndex = 3;
            this.choice3RadioButton.Text = "Choice 3";
            this.choice3RadioButton.UseVisualStyleBackColor = true;
            // 
            // choice4RadioButton
            // 
            this.choice4RadioButton.AutoSize = true;
            this.choice4RadioButton.Location = new System.Drawing.Point(53, 307);
            this.choice4RadioButton.Name = "choice4RadioButton";
            this.choice4RadioButton.Size = new System.Drawing.Size(84, 21);
            this.choice4RadioButton.TabIndex = 4;
            this.choice4RadioButton.Text = "Choice 4";
            this.choice4RadioButton.UseVisualStyleBackColor = true;
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(370, 348);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(92, 31);
            this.submitButton.TabIndex = 1;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // choice1TextBox
            // 
            this.choice1TextBox.Location = new System.Drawing.Point(154, 187);
            this.choice1TextBox.Name = "choice1TextBox";
            this.choice1TextBox.ReadOnly = true;
            this.choice1TextBox.Size = new System.Drawing.Size(308, 22);
            this.choice1TextBox.TabIndex = 1;
            // 
            // choice2TextBox
            // 
            this.choice2TextBox.Location = new System.Drawing.Point(154, 230);
            this.choice2TextBox.Name = "choice2TextBox";
            this.choice2TextBox.ReadOnly = true;
            this.choice2TextBox.Size = new System.Drawing.Size(308, 22);
            this.choice2TextBox.TabIndex = 8;
            // 
            // choice3TextBox
            // 
            this.choice3TextBox.Location = new System.Drawing.Point(154, 270);
            this.choice3TextBox.Name = "choice3TextBox";
            this.choice3TextBox.ReadOnly = true;
            this.choice3TextBox.Size = new System.Drawing.Size(308, 22);
            this.choice3TextBox.TabIndex = 9;
            // 
            // choice4TextBox
            // 
            this.choice4TextBox.Location = new System.Drawing.Point(154, 307);
            this.choice4TextBox.Name = "choice4TextBox";
            this.choice4TextBox.ReadOnly = true;
            this.choice4TextBox.Size = new System.Drawing.Size(308, 22);
            this.choice4TextBox.TabIndex = 10;
            // 
            // questionLabel
            // 
            this.questionLabel.AutoSize = true;
            this.questionLabel.Location = new System.Drawing.Point(53, 26);
            this.questionLabel.Name = "questionLabel";
            this.questionLabel.Size = new System.Drawing.Size(65, 17);
            this.questionLabel.TabIndex = 11;
            this.questionLabel.Text = "Question";
            // 
            // feedbackLabel
            // 
            this.feedbackLabel.AutoSize = true;
            this.feedbackLabel.Location = new System.Drawing.Point(53, 378);
            this.feedbackLabel.Name = "feedbackLabel";
            this.feedbackLabel.Size = new System.Drawing.Size(70, 17);
            this.feedbackLabel.TabIndex = 12;
            this.feedbackLabel.Text = "Feedback";
            // 
            // questionTextBox
            // 
            this.questionTextBox.Location = new System.Drawing.Point(53, 49);
            this.questionTextBox.Multiline = true;
            this.questionTextBox.Name = "questionTextBox";
            this.questionTextBox.ReadOnly = true;
            this.questionTextBox.Size = new System.Drawing.Size(409, 101);
            this.questionTextBox.TabIndex = 0;
            // 
            // questionNumberLabel
            // 
            this.questionNumberLabel.AutoSize = true;
            this.questionNumberLabel.Location = new System.Drawing.Point(125, 26);
            this.questionNumberLabel.Name = "questionNumberLabel";
            this.questionNumberLabel.Size = new System.Drawing.Size(16, 17);
            this.questionNumberLabel.TabIndex = 13;
            this.questionNumberLabel.Text = "0";
            // 
            // outOf3Label
            // 
            this.outOf3Label.AutoSize = true;
            this.outOf3Label.Location = new System.Drawing.Point(147, 26);
            this.outOf3Label.Name = "outOf3Label";
            this.outOf3Label.Size = new System.Drawing.Size(56, 17);
            this.outOf3Label.TabIndex = 14;
            this.outOf3Label.Text = "out of 3";
            // 
            // startPictureBox
            // 
            this.startPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("startPictureBox.Image")));
            this.startPictureBox.Location = new System.Drawing.Point(13, 26);
            this.startPictureBox.Name = "startPictureBox";
            this.startPictureBox.Size = new System.Drawing.Size(569, 471);
            this.startPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.startPictureBox.TabIndex = 15;
            this.startPictureBox.TabStop = false;
            // 
            // startButton
            // 
            this.startButton.Location = new System.Drawing.Point(429, 398);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(84, 31);
            this.startButton.TabIndex = 16;
            this.startButton.Text = "Start";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // nextButton
            // 
            this.nextButton.Location = new System.Drawing.Point(370, 348);
            this.nextButton.Name = "nextButton";
            this.nextButton.Size = new System.Drawing.Size(92, 31);
            this.nextButton.TabIndex = 1;
            this.nextButton.Text = "Next";
            this.nextButton.UseVisualStyleBackColor = true;
            this.nextButton.Visible = false;
            this.nextButton.Click += new System.EventHandler(this.nextButton_Click);
            // 
            // rightPictureBox
            // 
            this.rightPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("rightPictureBox.Image")));
            this.rightPictureBox.Location = new System.Drawing.Point(490, 208);
            this.rightPictureBox.Name = "rightPictureBox";
            this.rightPictureBox.Size = new System.Drawing.Size(100, 84);
            this.rightPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.rightPictureBox.TabIndex = 18;
            this.rightPictureBox.TabStop = false;
            this.rightPictureBox.Visible = false;
            // 
            // wrongPictureBox
            // 
            this.wrongPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("wrongPictureBox.Image")));
            this.wrongPictureBox.Location = new System.Drawing.Point(490, 208);
            this.wrongPictureBox.Name = "wrongPictureBox";
            this.wrongPictureBox.Size = new System.Drawing.Size(100, 84);
            this.wrongPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.wrongPictureBox.TabIndex = 19;
            this.wrongPictureBox.TabStop = false;
            this.wrongPictureBox.Visible = false;
            // 
            // feedbackTextBox
            // 
            this.feedbackTextBox.Location = new System.Drawing.Point(53, 398);
            this.feedbackTextBox.Multiline = true;
            this.feedbackTextBox.Name = "feedbackTextBox";
            this.feedbackTextBox.ReadOnly = true;
            this.feedbackTextBox.Size = new System.Drawing.Size(409, 88);
            this.feedbackTextBox.TabIndex = 6;
            // 
            // Game
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(594, 509);
            this.Controls.Add(this.wrongPictureBox);
            this.Controls.Add(this.rightPictureBox);
            this.Controls.Add(this.nextButton);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.startPictureBox);
            this.Controls.Add(this.outOf3Label);
            this.Controls.Add(this.questionNumberLabel);
            this.Controls.Add(this.feedbackLabel);
            this.Controls.Add(this.questionLabel);
            this.Controls.Add(this.choice4TextBox);
            this.Controls.Add(this.choice3TextBox);
            this.Controls.Add(this.choice2TextBox);
            this.Controls.Add(this.choice1TextBox);
            this.Controls.Add(this.feedbackTextBox);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.choice4RadioButton);
            this.Controls.Add(this.choice3RadioButton);
            this.Controls.Add(this.choice2RadioButton);
            this.Controls.Add(this.choice1RadioButton);
            this.Controls.Add(this.questionTextBox);
            this.Name = "Game";
            this.Text = "Game";
            ((System.ComponentModel.ISupportInitialize)(this.startPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rightPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wrongPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.RadioButton choice1RadioButton;
        private System.Windows.Forms.RadioButton choice2RadioButton;
        private System.Windows.Forms.RadioButton choice3RadioButton;
        private System.Windows.Forms.RadioButton choice4RadioButton;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.TextBox choice1TextBox;
        private System.Windows.Forms.TextBox choice2TextBox;
        private System.Windows.Forms.TextBox choice3TextBox;
        private System.Windows.Forms.TextBox choice4TextBox;
        private System.Windows.Forms.Label questionLabel;
        private System.Windows.Forms.Label feedbackLabel;
        private System.Windows.Forms.TextBox questionTextBox;
        private System.Windows.Forms.Label questionNumberLabel;
        private System.Windows.Forms.Label outOf3Label;
        private System.Windows.Forms.PictureBox startPictureBox;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Button nextButton;
        private System.Windows.Forms.PictureBox rightPictureBox;
        private System.Windows.Forms.PictureBox wrongPictureBox;
        private System.Windows.Forms.TextBox feedbackTextBox;
    }
}