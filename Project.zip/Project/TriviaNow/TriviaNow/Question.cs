﻿// Project, David Lu, CIS 345, T-TH 12pm
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TriviaNow
{
    [Serializable]
    public class Question
    {
        private string newQuestion;
        private string choice1;
        private string choice2;
        private string choice3;
        private string choice4;
        private string feedback;
        private string correctChoice;

        public Question()
        {
            this.newQuestion = "";
            this.choice1 = "";
            this.choice2 = "";
            this.choice3 = "";
            this.choice4 = "";
            this.feedback = "";
            this.CorrectChoice = "";
        }

        public Question(string newQuestion, string choice1, string choice2, string choice3, string choice4, string feedback, string correctChoice)
        {
            this.newQuestion = newQuestion;
            this.choice1 = choice1;
            this.choice2 = choice2;
            this.choice3 = choice3;
            this.choice4 = choice4;
            this.feedback = feedback;
            this.CorrectChoice = correctChoice;
        }

        public string NewQuestion { get => newQuestion; set => newQuestion = value; }
        public string Choice1 { get => choice1; set => choice1 = value; }
        public string Choice2 { get => choice2; set => choice2 = value; }
        public string Choice3 { get => choice3; set => choice3 = value; }
        public string Choice4 { get => choice4; set => choice4 = value; }
        public string Feedback { get => feedback; set => feedback = value; }
        public string CorrectChoice { get => correctChoice; set => correctChoice = value; }

        public override string ToString()
        {
            return $"{newQuestion}";
        }
    }
}
