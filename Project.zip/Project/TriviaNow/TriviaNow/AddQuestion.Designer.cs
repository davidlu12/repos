﻿namespace TriviaNow
{
    partial class AddQuestion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.questionTextBox = new System.Windows.Forms.TextBox();
            this.choice1TextBox = new System.Windows.Forms.TextBox();
            this.choice2TextBox = new System.Windows.Forms.TextBox();
            this.choice3TextBox = new System.Windows.Forms.TextBox();
            this.choice4TextBox = new System.Windows.Forms.TextBox();
            this.feedbackTextBox = new System.Windows.Forms.TextBox();
            this.addButton = new System.Windows.Forms.Button();
            this.QuestionLabel = new System.Windows.Forms.Label();
            this.choice1Label = new System.Windows.Forms.Label();
            this.choice2Label = new System.Windows.Forms.Label();
            this.choice3Label = new System.Windows.Forms.Label();
            this.choice4Label = new System.Windows.Forms.Label();
            this.feedbackLabel = new System.Windows.Forms.Label();
            this.addQuestionGroupBox = new System.Windows.Forms.GroupBox();
            this.correctChoiceTextBox = new System.Windows.Forms.TextBox();
            this.correctChoiceLabel = new System.Windows.Forms.Label();
            this.editButton = new System.Windows.Forms.Button();
            this.addQuestionGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // questionTextBox
            // 
            this.questionTextBox.Location = new System.Drawing.Point(162, 32);
            this.questionTextBox.Multiline = true;
            this.questionTextBox.Name = "questionTextBox";
            this.questionTextBox.Size = new System.Drawing.Size(433, 60);
            this.questionTextBox.TabIndex = 0;
            // 
            // choice1TextBox
            // 
            this.choice1TextBox.Location = new System.Drawing.Point(162, 103);
            this.choice1TextBox.Name = "choice1TextBox";
            this.choice1TextBox.Size = new System.Drawing.Size(433, 22);
            this.choice1TextBox.TabIndex = 1;
            // 
            // choice2TextBox
            // 
            this.choice2TextBox.Location = new System.Drawing.Point(162, 131);
            this.choice2TextBox.Name = "choice2TextBox";
            this.choice2TextBox.Size = new System.Drawing.Size(433, 22);
            this.choice2TextBox.TabIndex = 2;
            // 
            // choice3TextBox
            // 
            this.choice3TextBox.Location = new System.Drawing.Point(162, 159);
            this.choice3TextBox.Name = "choice3TextBox";
            this.choice3TextBox.Size = new System.Drawing.Size(433, 22);
            this.choice3TextBox.TabIndex = 3;
            // 
            // choice4TextBox
            // 
            this.choice4TextBox.Location = new System.Drawing.Point(162, 187);
            this.choice4TextBox.Name = "choice4TextBox";
            this.choice4TextBox.Size = new System.Drawing.Size(433, 22);
            this.choice4TextBox.TabIndex = 4;
            // 
            // feedbackTextBox
            // 
            this.feedbackTextBox.Location = new System.Drawing.Point(162, 215);
            this.feedbackTextBox.Multiline = true;
            this.feedbackTextBox.Name = "feedbackTextBox";
            this.feedbackTextBox.Size = new System.Drawing.Size(433, 54);
            this.feedbackTextBox.TabIndex = 5;
            // 
            // addButton
            // 
            this.addButton.Location = new System.Drawing.Point(498, 393);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(141, 34);
            this.addButton.TabIndex = 6;
            this.addButton.Text = "Add Question";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // QuestionLabel
            // 
            this.QuestionLabel.AutoSize = true;
            this.QuestionLabel.Location = new System.Drawing.Point(24, 32);
            this.QuestionLabel.Name = "QuestionLabel";
            this.QuestionLabel.Size = new System.Drawing.Size(100, 17);
            this.QuestionLabel.TabIndex = 7;
            this.QuestionLabel.Text = "Question Text:";
            // 
            // choice1Label
            // 
            this.choice1Label.AutoSize = true;
            this.choice1Label.Location = new System.Drawing.Point(24, 103);
            this.choice1Label.Name = "choice1Label";
            this.choice1Label.Size = new System.Drawing.Size(67, 17);
            this.choice1Label.TabIndex = 8;
            this.choice1Label.Text = "Choice 1:";
            // 
            // choice2Label
            // 
            this.choice2Label.AutoSize = true;
            this.choice2Label.Location = new System.Drawing.Point(24, 131);
            this.choice2Label.Name = "choice2Label";
            this.choice2Label.Size = new System.Drawing.Size(67, 17);
            this.choice2Label.TabIndex = 9;
            this.choice2Label.Text = "Choice 2:";
            // 
            // choice3Label
            // 
            this.choice3Label.AutoSize = true;
            this.choice3Label.Location = new System.Drawing.Point(24, 159);
            this.choice3Label.Name = "choice3Label";
            this.choice3Label.Size = new System.Drawing.Size(67, 17);
            this.choice3Label.TabIndex = 10;
            this.choice3Label.Text = "Choice 3:";
            // 
            // choice4Label
            // 
            this.choice4Label.AutoSize = true;
            this.choice4Label.Location = new System.Drawing.Point(24, 187);
            this.choice4Label.Name = "choice4Label";
            this.choice4Label.Size = new System.Drawing.Size(67, 17);
            this.choice4Label.TabIndex = 11;
            this.choice4Label.Text = "Choice 4:";
            // 
            // feedbackLabel
            // 
            this.feedbackLabel.AutoSize = true;
            this.feedbackLabel.Location = new System.Drawing.Point(24, 215);
            this.feedbackLabel.Name = "feedbackLabel";
            this.feedbackLabel.Size = new System.Drawing.Size(74, 17);
            this.feedbackLabel.TabIndex = 12;
            this.feedbackLabel.Text = "Feedback:";
            // 
            // addQuestionGroupBox
            // 
            this.addQuestionGroupBox.Controls.Add(this.correctChoiceTextBox);
            this.addQuestionGroupBox.Controls.Add(this.correctChoiceLabel);
            this.addQuestionGroupBox.Controls.Add(this.QuestionLabel);
            this.addQuestionGroupBox.Controls.Add(this.feedbackLabel);
            this.addQuestionGroupBox.Controls.Add(this.questionTextBox);
            this.addQuestionGroupBox.Controls.Add(this.choice4Label);
            this.addQuestionGroupBox.Controls.Add(this.choice3Label);
            this.addQuestionGroupBox.Controls.Add(this.choice1Label);
            this.addQuestionGroupBox.Controls.Add(this.choice1TextBox);
            this.addQuestionGroupBox.Controls.Add(this.choice2Label);
            this.addQuestionGroupBox.Controls.Add(this.choice2TextBox);
            this.addQuestionGroupBox.Controls.Add(this.choice3TextBox);
            this.addQuestionGroupBox.Controls.Add(this.feedbackTextBox);
            this.addQuestionGroupBox.Controls.Add(this.choice4TextBox);
            this.addQuestionGroupBox.Location = new System.Drawing.Point(28, 51);
            this.addQuestionGroupBox.Name = "addQuestionGroupBox";
            this.addQuestionGroupBox.Size = new System.Drawing.Size(611, 320);
            this.addQuestionGroupBox.TabIndex = 13;
            this.addQuestionGroupBox.TabStop = false;
            this.addQuestionGroupBox.Text = "Question Details";
            // 
            // correctChoiceTextBox
            // 
            this.correctChoiceTextBox.Location = new System.Drawing.Point(162, 275);
            this.correctChoiceTextBox.Name = "correctChoiceTextBox";
            this.correctChoiceTextBox.Size = new System.Drawing.Size(433, 22);
            this.correctChoiceTextBox.TabIndex = 14;
            // 
            // correctChoiceLabel
            // 
            this.correctChoiceLabel.AutoSize = true;
            this.correctChoiceLabel.Location = new System.Drawing.Point(24, 275);
            this.correctChoiceLabel.Name = "correctChoiceLabel";
            this.correctChoiceLabel.Size = new System.Drawing.Size(105, 17);
            this.correctChoiceLabel.TabIndex = 13;
            this.correctChoiceLabel.Text = "Correct Choice:";
            // 
            // editButton
            // 
            this.editButton.Location = new System.Drawing.Point(498, 402);
            this.editButton.Name = "editButton";
            this.editButton.Size = new System.Drawing.Size(141, 34);
            this.editButton.TabIndex = 14;
            this.editButton.Text = "Edit Question";
            this.editButton.UseVisualStyleBackColor = true;
            this.editButton.Visible = false;
            this.editButton.Click += new System.EventHandler(this.editButton_Click);
            // 
            // AddQuestion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(680, 477);
            this.Controls.Add(this.editButton);
            this.Controls.Add(this.addQuestionGroupBox);
            this.Controls.Add(this.addButton);
            this.Name = "AddQuestion";
            this.Text = "AddQuestion";
            this.addQuestionGroupBox.ResumeLayout(false);
            this.addQuestionGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox questionTextBox;
        private System.Windows.Forms.TextBox choice1TextBox;
        private System.Windows.Forms.TextBox choice2TextBox;
        private System.Windows.Forms.TextBox choice3TextBox;
        private System.Windows.Forms.TextBox choice4TextBox;
        private System.Windows.Forms.TextBox feedbackTextBox;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Label QuestionLabel;
        private System.Windows.Forms.Label choice1Label;
        private System.Windows.Forms.Label choice2Label;
        private System.Windows.Forms.Label choice3Label;
        private System.Windows.Forms.Label choice4Label;
        private System.Windows.Forms.Label feedbackLabel;
        private System.Windows.Forms.GroupBox addQuestionGroupBox;
        private System.Windows.Forms.TextBox correctChoiceTextBox;
        private System.Windows.Forms.Label correctChoiceLabel;
        private System.Windows.Forms.Button editButton;
    }
}