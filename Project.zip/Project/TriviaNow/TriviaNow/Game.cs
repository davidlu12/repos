﻿// Project, David Lu, CIS 345, T-TH 12pm
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace TriviaNow
{
    public partial class Game : Form
    {
        int answer;
        int selectedAnswer;
        int count=1;
        int correctCount;
        string feedback;
        BindingList<Question> questionList;
        SoundPlayer soundPlayer;
        List<int> randomIndex = new List<int>();

        public Game()
        {
            InitializeComponent();
        }

        // randomize the questions
        public void RandomQuestion()
        {
            Random randomGenerator;
            int index;
            bool unique;
            randomGenerator = new Random();
            do
            {
                index = randomGenerator.Next(0, questionList.Count);
                if(!randomIndex.Contains(index))
                {
                    randomIndex.Add(index);
                    PopulateData(index);
                    return;
                }
                else
                {
                    unique = false;
                }
            } while (unique ==false);
        }
        // populates the data into the game form and stores the correct answer
        private void PopulateData(int index)
        {
            Question tmpQuestion;
            tmpQuestion = questionList.ElementAt(index);
            questionTextBox.Text = tmpQuestion.NewQuestion;
            choice1TextBox.Text = tmpQuestion.Choice1;
            choice2TextBox.Text = tmpQuestion.Choice2;
            choice3TextBox.Text = tmpQuestion.Choice3;
            choice4TextBox.Text = tmpQuestion.Choice4;
            feedback = tmpQuestion.Feedback;
            feedbackTextBox.Visible = false;
            feedbackLabel.Visible = false;
            answer = Convert.ToInt32(tmpQuestion.CorrectChoice);
        }

        // checks if the correct answer is chosen 
        private void submitButton_Click(object sender, EventArgs e)
        {

            if(choice1RadioButton.Checked)
            {
                selectedAnswer = 1;
            }
            if (choice2RadioButton.Checked)
            {
                selectedAnswer = 2;
            }
            if (choice3RadioButton.Checked)
            {
                selectedAnswer = 3;
            }
            if (choice4RadioButton.Checked)
            {
                selectedAnswer = 4;
            }
            if (answer==selectedAnswer)
            {
                questionNumberLabel.Text = Convert.ToString(count++);
                feedbackTextBox.Visible = true;
                feedbackLabel.Visible = true;
                feedbackTextBox.Text = "Congrats, That is correct!";
                ++correctCount;
                rightPictureBox.Visible = true;
                soundPlayer = new SoundPlayer("correct.wav");
                soundPlayer.Load();
                soundPlayer.Play();
            }
            else
            {
                questionNumberLabel.Text = Convert.ToString(count++);
                feedbackTextBox.Visible = true;
                feedbackLabel.Visible = true;
                feedbackTextBox.Text = feedback;
                wrongPictureBox.Visible = true;
                soundPlayer = new SoundPlayer("wrong.wav");
                soundPlayer.Load();
                soundPlayer.Play();
            }
            if(count<4)
            {
                nextButton.Visible = true;
                submitButton.Visible = false;
            }
            else
            {
                MessageBox.Show($"Game over! You answered {correctCount}/3 correctly");
                this.Close();
            }
        }

        // calls the randomQuestion method and populates the question also hiding the start picture
        private void startButton_Click(object sender, EventArgs e)
        {
            startPictureBox.Visible = false;
            startButton.Visible = false;
            RandomQuestion();
        }

        // sets the data from the questionlist in the manager form
        public void SetData(BindingList<Question> question)
        {
            questionList = question;
        }

        // proceeds to the next question
        private void nextButton_Click(object sender, EventArgs e)
        {
            rightPictureBox.Visible = false;
            wrongPictureBox.Visible = false;
            nextButton.Visible = false;
            submitButton.Visible = true;
            RandomQuestion();
        }
    }
}
