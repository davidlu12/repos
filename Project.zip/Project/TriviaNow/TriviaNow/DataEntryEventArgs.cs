﻿// Project, David Lu, CIS 345, T-TH 12pm
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TriviaNow
{
    class DataEntryEventArgs : EventArgs
    {
        Question question;

        public DataEntryEventArgs(Question question)
        {
            this.question = question;
        }

        public Question Question { get => question; set => question = value; }
    }
}
